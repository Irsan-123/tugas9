/**
 * TODO 1:
 * - Buat array yang berisi data buah.
 * - Refactor variable ke ES6 Variable.
 */
const fruits = ["Banana","Manggo","durian"];

 // TODO 2: export variable fruits
module.exports = fruits;